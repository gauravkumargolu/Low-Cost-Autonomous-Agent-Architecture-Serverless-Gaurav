# Serverless Agent — Live Cost Calculator

An interactive cost calculator for a low-cost, 100% serverless AWS Bedrock agent architecture. Adjust monthly interaction volume, model mix, token usage, and infrastructure settings to see live AWS cost estimates — and how they compare to a traditional always-on architecture.

**Live demo:** _(add your Netlify URL here after deploying)_

## Files
- `index.html` — the calculator (self-contained, no build step)
- `og-image.png` / `og-image.svg` — social share preview image
- `LICENSE` — MIT license

## Features
- Live cost recalculation across 15 AWS services (Bedrock, Lambda, Aurora Serverless v2, DynamoDB, API Gateway, Step Functions, and more)
- Quick-scenario presets: Pilot, Production, Scale, Enterprise
- Side-by-side comparison against a traditional always-on architecture
- Cost composition breakdown by category

## Deploy on Netlify (no account needed for a quick link)
1. Go to **app.netlify.com/drop**
2. Drag this entire folder onto the page
3. Netlify gives you a live URL immediately (e.g. `https://random-name-123.netlify.app`)
4. Optional: claim a free Netlify account to keep the link permanent and pick a custom subdomain

## Deploy on GitHub Pages (alternative)
1. Push this folder to a GitHub repo
2. **Settings → Pages → Source → Deploy from a branch → main / (root)**
3. Live at `https://<username>.github.io/<repo-name>/`

---
Developed by **Gaurav Kumar**
